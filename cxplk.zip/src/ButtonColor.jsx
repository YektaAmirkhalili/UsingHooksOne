function buttonColor() {
  return;
}

export default buttonColor;
