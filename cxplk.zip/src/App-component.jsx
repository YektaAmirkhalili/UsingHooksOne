function AppComp() {
  return <p>Hello</p>;
}

export default AppComp;
