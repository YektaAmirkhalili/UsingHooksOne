import "./styles.css";
import AppComp from "./App-component";
import { useState } from "react";
// import buttonColor from "./ButtonColor";

export default function App() {
  // console.log(AppComp());
  const [stateVal, setStateVal] = useState("Before Click.");
  const handleClick = () => {
    setStateVal("After Click.");
  };
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <AppComp />
      <h2>Start editing to see some magic happen!</h2>
      <button onClick={handleClick}>Click Me</button>
      <p>Value: {stateVal} </p>
    </div>
  );
}
